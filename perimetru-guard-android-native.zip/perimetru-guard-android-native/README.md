# Perimetru Guard — Android nativ

Aplicație Android nativă, fără PWA și fără Capacitor.

Funcții:
- configurare latitudine, longitudine și rază;
- geofence Android persistent cu intrare/ieșire;
- notificare persistentă cu vibrații și buton de oprire;
- oprire automată când aplicația configurată este deschisă;
- serviciu Accessibility care compară doar numele pachetului din prim-plan;
- datele sunt salvate local.

## Build APK din GitHub, direct de pe telefon

1. Încarcă folderul `android` și folderul `.github` în repository.
2. Workflow-ul este `.github/workflows/android.yml`.
3. În GitHub: **Actions → Build Android APK → Run workflow**.
4. După finalizare: **Artifacts → perimetru-guard-debug-apk**.

Nu este necesar Android Studio sau PC-ul tău. GitHub Actions folosește Android SDK și JDK în cloud.

## Permisiuni pe telefon

Acordă locație, notificări și activează serviciul din **Setări → Accesibilitate → Servicii instalate → Perimetru Guard**. Pentru locație în fundal, Android poate cere activarea separată a opțiunii „Tot timpul”.

> Android și producătorul telefonului pot întârzia geofence-ul sau limita vibrațiile prin Battery Saver. Aplicația nu ocolește controalele sistemului.
