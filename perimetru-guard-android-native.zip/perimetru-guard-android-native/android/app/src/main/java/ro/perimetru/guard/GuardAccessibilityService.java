package ro.perimetru.guard;
import android.accessibilityservice.AccessibilityService; import android.view.accessibility.AccessibilityEvent;
public class GuardAccessibilityService extends AccessibilityService {
  @Override public void onAccessibilityEvent(AccessibilityEvent e) { String target=GuardStore.target(this); if (GuardStore.alerting(this) && !target.isEmpty() && target.equals(e.getPackageName()==null?"":e.getPackageName().toString())) AlertService.stop(this); }
  @Override public void onInterrupt() {}
}
