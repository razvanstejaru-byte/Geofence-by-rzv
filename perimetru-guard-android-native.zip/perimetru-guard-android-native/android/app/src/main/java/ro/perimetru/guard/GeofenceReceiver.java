package ro.perimetru.guard;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.location.GeofencingEvent;

public class GeofenceReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    GeofencingEvent event = GeofencingEvent.fromIntent(intent);
    if (event != null && !event.hasError() && event.getGeofenceTransition() != 0) {
      GuardStore.setAlerting(context, true);
      AlertService.start(context, event.getGeofenceTransition());
    }
  }
}
