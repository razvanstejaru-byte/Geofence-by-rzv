package ro.perimetru.guard;

import android.content.Context;
import android.content.SharedPreferences;

final class GuardStore {
  private static final String PREFS = "guard";
  static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
  static void save(Context c, double lat, double lng, float radius, String target, boolean enabled) {
    prefs(c).edit().putFloat("lat", (float)lat).putFloat("lng", (float)lng).putFloat("radius", radius).putString("target", target).putBoolean("enabled", enabled).apply();
  }
  static boolean enabled(Context c) { return prefs(c).getBoolean("enabled", false); }
  static String target(Context c) { return prefs(c).getString("target", ""); }
  static void setAlerting(Context c, boolean value) { prefs(c).edit().putBoolean("alerting", value).apply(); }
  static boolean alerting(Context c) { return prefs(c).getBoolean("alerting", false); }
}
