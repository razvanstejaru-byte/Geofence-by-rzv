package ro.perimetru.guard;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
  EditText lat, lng, radius, target; TextView status;
  static final int PERMISSION_REQUEST = 902;
  @Override public void onCreate(Bundle state) { super.onCreate(state); setContentView(R.layout.activity_main);
    lat=findViewById(R.id.latitude); lng=findViewById(R.id.longitude); radius=findViewById(R.id.radius); target=findViewById(R.id.target_package); status=findViewById(R.id.status);
    lat.setText(String.valueOf(GuardStore.prefs(this).getFloat("lat",44.4268f))); lng.setText(String.valueOf(GuardStore.prefs(this).getFloat("lng",26.1025f))); radius.setText(String.valueOf(GuardStore.prefs(this).getFloat("radius",150))); target.setText(GuardStore.target(this)); render();
    findViewById(R.id.save).setOnClickListener(v -> activate());
    findViewById(R.id.disable).setOnClickListener(v -> { GuardStore.prefs(this).edit().putBoolean("enabled",false).apply(); GeofenceCoordinator.unregister(this); render(); });
    findViewById(R.id.permissions).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    findViewById(R.id.use_location).setOnClickListener(v -> Toast.makeText(this,"Pentru localizare automată acordă permisiunea și folosește coordonatele afișate de aplicația de hărți.",Toast.LENGTH_LONG).show());
  }
  void activate() { try { double a=Double.parseDouble(lat.getText().toString()), b=Double.parseDouble(lng.getText().toString()); float r=Float.parseFloat(radius.getText().toString()); if(r<50) throw new IllegalArgumentException(); GuardStore.save(this,a,b,r,target.getText().toString().trim(),true); requestPermissions(); GeofenceCoordinator.register(this); render(); Toast.makeText(this,"Perimetrul a fost activat",Toast.LENGTH_SHORT).show(); } catch(Exception e) { Toast.makeText(this,"Verifică latitudinea, longitudinea și raza (minim 50 m).",Toast.LENGTH_LONG).show(); } }
  void requestPermissions() { java.util.ArrayList<String> p=new java.util.ArrayList<>(); if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_FINE_LOCATION); if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_COARSE_LOCATION); if(android.os.Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.POST_NOTIFICATIONS); if(!p.isEmpty()) ActivityCompat.requestPermissions(this,p.toArray(new String[0]),PERMISSION_REQUEST); }
  void render(){ status.setText(GuardStore.enabled(this)?"Status: ACTIV — monitorizare pornită":"Status: inactiv"); }
  @Override public void onRequestPermissionsResult(int r,@NonNull String[] p,@NonNull int[] g){super.onRequestPermissionsResult(r,p,g); if(r==PERMISSION_REQUEST && android.os.Build.VERSION.SDK_INT>=30) Toast.makeText(this,"Activează și locația «tot timpul» din Setări → Permisiuni.",Toast.LENGTH_LONG).show();}
}
