package ro.perimetru.guard;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;

final class GeofenceCoordinator {
  private static final int REQUEST = 801;
  static void register(Context c) {
    GeofencingClient client = LocationServices.getGeofencingClient(c);
    float lat = GuardStore.prefs(c).getFloat("lat", 0), lng = GuardStore.prefs(c).getFloat("lng", 0), radius = GuardStore.prefs(c).getFloat("radius", 150);
    Geofence fence = new Geofence.Builder().setRequestId("guard-zone").setCircularRegion(lat, lng, radius).setExpirationDuration(Geofence.NEVER_EXPIRE).setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT).build();
    GeofencingRequest request = new GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER).addGeofence(fence).build();
    try { client.addGeofences(request, pending(c)).addOnFailureListener(e -> {}); } catch (SecurityException ignored) {}
  }
  static void unregister(Context c) { LocationServices.getGeofencingClient(c).removeGeofences(pending(c)); AlertService.stop(c); }
  private static PendingIntent pending(Context c) { Intent i = new Intent(c, GeofenceReceiver.class); return PendingIntent.getBroadcast(c, REQUEST, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE); }
}
