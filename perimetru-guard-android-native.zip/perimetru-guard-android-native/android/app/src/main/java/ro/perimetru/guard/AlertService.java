package ro.perimetru.guard;

import android.app.*; import android.content.*; import android.os.*; import androidx.core.app.NotificationCompat;

public class AlertService extends Service {
  static final String CHANNEL="guard-alert"; static final int ID=707;
  static void start(Context c, int transition) { Intent i=new Intent(c,AlertService.class).putExtra("transition",transition); androidx.core.content.ContextCompat.startForegroundService(c,i); }
  static void stop(Context c) { c.stopService(new Intent(c,AlertService.class)); ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID); GuardStore.setAlerting(c,false); }
  @Override public void onCreate() { super.onCreate(); NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Alerte perimetru",NotificationManager.IMPORTANCE_HIGH)); }
  @Override public int onStartCommand(Intent intent,int flags,int id) {
    Intent open=new Intent(this,MainActivity.class); PendingIntent content=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Intent stop=new Intent(this,StopAlertReceiver.class); PendingIntent stopPi=PendingIntent.getBroadcast(this,2,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Perimetru Guard: atenție").setContentText("Deschide aplicația configurată pentru a opri alerta.").setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM).setOngoing(true).setAutoCancel(false).setVibrate(new long[]{0,700,300,700}).setContentIntent(content).addAction(android.R.drawable.ic_menu_close_clear_cancel,"Oprește",stopPi).build();
    startForeground(ID,n); return START_STICKY;
  }
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
