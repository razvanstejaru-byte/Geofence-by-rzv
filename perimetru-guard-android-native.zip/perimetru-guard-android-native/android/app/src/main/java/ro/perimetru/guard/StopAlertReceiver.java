package ro.perimetru.guard;
import android.content.*;
public class StopAlertReceiver extends BroadcastReceiver { @Override public void onReceive(Context c, Intent i) { AlertService.stop(c); } }
